<?php

namespace WPParsidate\Admin;

defined( 'ABSPATH' ) || exit;

class AdminIntegration {
  public const tab = 'integration';
  public const icon = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M5.5 15.5C5.5 14.5572 5.5 14.0858 5.79289 13.7929C6.08579 13.5 6.55719 13.5 7.5 13.5H8.5C9.44281 13.5 9.91421 13.5 10.2071 13.7929C10.5 14.0858 10.5 14.5572 10.5 15.5V16.5C10.5 17.4428 10.5 17.9142 10.2071 18.2071C9.91421 18.5 9.44281 18.5 8.5 18.5C7.08579 18.5 6.37868 18.5 5.93934 18.0607C5.5 17.6213 5.5 16.9142 5.5 15.5Z" stroke="#3c3c3c" stroke-width="1.5"></path> <path d="M5.5 8.5C5.5 7.08579 5.5 6.37868 5.93934 5.93934C6.37868 5.5 7.08579 5.5 8.5 5.5C9.44281 5.5 9.91421 5.5 10.2071 5.79289C10.5 6.08579 10.5 6.55719 10.5 7.5V8.5C10.5 9.44281 10.5 9.91421 10.2071 10.2071C9.91421 10.5 9.44281 10.5 8.5 10.5H7.5C6.55719 10.5 6.08579 10.5 5.79289 10.2071C5.5 9.91421 5.5 9.44281 5.5 8.5Z" stroke="#3c3c3c" stroke-width="1.5"></path> <path d="M13.5 15.5C13.5 14.5572 13.5 14.0858 13.7929 13.7929C14.0858 13.5 14.5572 13.5 15.5 13.5H16.5C17.4428 13.5 17.9142 13.5 18.2071 13.7929C18.5 14.0858 18.5 14.5572 18.5 15.5C18.5 16.9142 18.5 17.6213 18.0607 18.0607C17.6213 18.5 16.9142 18.5 15.5 18.5C14.5572 18.5 14.0858 18.5 13.7929 18.2071C13.5 17.9142 13.5 17.4428 13.5 16.5V15.5Z" stroke="#3c3c3c" stroke-width="1.5"></path> <path d="M13.5 7.5C13.5 6.55719 13.5 6.08579 13.7929 5.79289C14.0858 5.5 14.5572 5.5 15.5 5.5C16.9142 5.5 17.6213 5.5 18.0607 5.93934C18.5 6.37868 18.5 7.08579 18.5 8.5C18.5 9.44281 18.5 9.91421 18.2071 10.2071C17.9142 10.5 17.4428 10.5 16.5 10.5H15.5C14.5572 10.5 14.0858 10.5 13.7929 10.2071C13.5 9.91421 13.5 9.44281 13.5 8.5V7.5Z" stroke="#3c3c3c" stroke-width="1.5"></path> <path d="M22 14C22 17.7712 22 19.6569 20.8284 20.8284C19.6569 22 17.7712 22 14 22" stroke="#3c3c3c" stroke-width="1.5" stroke-linecap="round"></path> <path d="M10 22C6.22876 22 4.34315 22 3.17157 20.8284C2 19.6569 2 17.7712 2 14" stroke="#3c3c3c" stroke-width="1.5" stroke-linecap="round"></path> <path d="M10 2C6.22876 2 4.34315 2 3.17157 3.17157C2 4.34315 2 6.22876 2 10" stroke="#3c3c3c" stroke-width="1.5" stroke-linecap="round"></path> <path d="M14 2C17.7712 2 19.6569 2 20.8284 3.17157C22 4.34315 22 6.22876 22 10" stroke="#3c3c3c" stroke-width="1.5" stroke-linecap="round"></path> </g></svg>';

  private static ?array $settings = null;

  public function __construct() {
    add_filter( 'wp_parsidate_menus', [ $this, 'addMenu' ] );
    add_filter( 'wp_parsidate_' . self::tab . '_settings', [ $this, 'settings' ] );
    add_filter( 'wp_parsidate_settings', [ $this, 'allSettings' ] );
    add_filter( 'wp_parsidate_' . self::tab . '_tab_display_notice', '__return_false' );
    add_filter( 'wp_parsidate_' . self::tab . '_tab_content_display_notice', '__return_true' );
  }

  public function addMenu( $menus ) {
    $settings = $this->settings();
    if ( ! empty( $settings['sections'] ) ) {
      $menus[ self::tab ] = array(
        'title' => esc_html__( 'Integration', 'wp-parsidate' ),
        'icon'  => self::icon
      );
    }

    return $menus;
  }

  public function allSettings( $settings ): array {
    $settings[ self::tab ] = $this->settings();

    return $settings;
  }

  public function settings(): array {
    if ( self::$settings === null ) {
      self::$settings = array(
        'title'    => esc_html__( 'Integration settings', 'wp-parsidate' ),
        'desc'     => esc_html__( 'Global plugin settings', 'wp-parsidate' ),
        'sections' => apply_filters( 'wp_parsidate_' . self::tab . '_settings_sections', [] )
      );
    }

    return self::$settings;
  }
}
