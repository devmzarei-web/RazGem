<?php

namespace PW\PWSMS\Gateways;

use SoapClient;
use SoapFault;

class IranSMSServer extends Gateway {

	public static function id(): string {
		return 'iransmsserver';
	}

	public static function name(): string {
		return 'iransmsserver.com';
	}

	public function send() {
		$username = $this->username;
		$password = $this->password;
		$from     = $this->senderNumber;
		$to       = $this->mobile;
		$massage  = $this->message;

		if ( empty( $username ) || empty( $password ) ) {
			return false;
		}

		try {
			$client       = new SoapClient( "http://sms.iransmsserver.ir/post/send.asmx?wsdl" );
			$encoding     = "UTF-8";
			$parameters   = [
				'username' => $username,
				'password' => $password,
				'from'     => $from,
				'to'       => $to,
				'text'     => iconv( $encoding, 'UTF-8//TRANSLIT', $massage ),
				'isflash'  => false,
				'udh'      => "",
				'recId'    => [ 0 ],
				'status'   => 0,
			];
			$sms_response = $client->SendSms( $parameters )->SendSmsResult;
		} catch ( SoapFault $ex ) {
			$sms_response = $ex->getMessage();
		}

		if ( $sms_response == 1 ) {
			return true; // Success
		} else {
			$response = $sms_response;
		}

		return $response;
	}
}
