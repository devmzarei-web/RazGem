<?php
/**
 * Copyright 2010-2013 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

namespace DuplicatorPro\Aws\S3\Model\MultipartUpload;

defined("ABSPATH") or die("");

use DuplicatorPro\Aws\Common\Model\MultipartUpload\AbstractUploadId;

/**
 * An object that encapsulates the identification for a Glacier upload part
 * @codeCoverageIgnore
 */
class UploadId extends AbstractUploadId
{
    /**
     * {@inheritdoc}
     */
    protected static $expectedValues = array(
        'Bucket'   => false,
        'Key'      => false,
        'UploadId' => false
    );
}
